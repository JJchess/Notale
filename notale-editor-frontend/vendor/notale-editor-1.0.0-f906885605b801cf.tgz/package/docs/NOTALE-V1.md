# Native Notale v1 integration

The editor consumes the current `notale-ts` `.notale` output. Legacy ZIP manifests are no longer accepted. PPTX import remains a separate frontend conversion path.

`@notale/format` is the small sibling contract package. Build it before source consumers (`npm ci && npm run build` in `notale-format`). The editor build also compiles this contract and its cache fingerprints the contract sources. Packed editor distributions bundle the contract; consumers do not need the harness.

## File and HTTP contract

- ZIP container, `.notale` extension; `notale-project.json` contains `format: "notale"`, `formatVersion: 1`, `entry: "index.html"` and `document`.
- The container version and `document.schemaVersion` are independent. `document.slides` and their author HTML are authoritative. Rendered root pages never become additional slides.
- `POST /api/import` receives raw bytes with `Content-Type: application/octet-stream`, maximum 75 MB. The expanded limit is 150 MB / 10,000 entries. Unsafe/duplicate paths, reserved path collisions, missing resources, unsupported versions and incorrect asset hashes are rejected before a document revision is created.
- `GET /api/documents/:id/export` returns the current title as an RFC 5987 `.notale` filename. It regenerates the player and rendered pages from the requested revision. Fonts, nested runtime assets and notices retain their relative paths. Compression and decompression use asynchronous workers.
- `npm run import:slides -- lecture.notale` imports a native package directly. `EDITOR_URL` selects the API origin.

## Author and runtime separation

Native steps use `data-deck-step`; literal `Deck.onStep(callback, maximum)` declarations are also detected without executing code. The persisted count is the maximum index, not the number of states. Runtime `Deck.stepMax` remains authoritative for computed declarations. Edit mode exposes authored step elements and removes their inert state; presentation restores the native step state.

`themeTokens` records discovered root color, font and type-size defaults. It is a catalog, not a copy of values into `document.theme`: existing stylesheets and page defaults remain in place. Explicit author overrides still use the existing incremental theme command. Published subset fonts and full fallback font resources travel unchanged with the package.

The envelope's `pageRuntimes` and rendered `__NOTALE__.pageRuntime` describe version, page kind, native step maximum and the identity/entry of embedded workbenches. These are derived from current author HTML, not execution snapshots.

Code-workbench iframe addresses are explicit in author HTML even when the harness playback file used `data-src`. Iframes can be moved, resized, duplicated and deleted as independent objects. Editor mode intercepts object selection; preview/presentation owns code input, run/reset and trace controls. Learner edits to Monaco models do not overwrite author sources.

CodeLab v1 exposes pause/resume alongside run/reset/state/dispose. Hidden cached pages pause workbench playback. Removing an iframe releases its runtime; reordering uses state-preserving DOM moves where supported and avoids moving unchanged siblings. Readiness of the outer slide does not wait for Monaco or Python.

The editor retains bounded page caching and visible-only thumbnails. Existing artifacts without image posters still use live thumbnail rendering; no screenshot generation pipeline is introduced in this upgrade.

## Scope and verification

No identity system, AI editing pipeline, prompt, model configuration or generation workflow is changed. Harness changes are deterministic archive metadata and CodeLab lifecycle API additions. Existing database contents are not migrated or deleted.

Focused checks cover container validation, source identities, theme discovery, literal/native steps, iframe copy semantics, and an actual PostgreSQL export/import round trip. Integration samples are the current eight-page seed lecture and seven-page regression lecture with Python workbench. Preview deployments retain the previous frontend/backend for rollback.
